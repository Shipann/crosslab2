<?php
$translate = array(
    "login" => "Login",
    "pass" => "Password",

    "msgAdm" => "Hello , Admin",
    "msgMan" => "Hello , Manager",
    "msgCli" => "Hello , Client",
    "msgAdm2" => ", You can modify, delete and create clients on the site.",
    "msgMan2" => ", You can modify and create clients on the site.",
    "msgCli2" => ", You can view information available to users on the site.",

);

