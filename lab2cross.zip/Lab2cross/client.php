<?php
@session_start();
$LangArray = array("ru", "ua", "en");
$DefaultLang = "ru";


$language = addslashes($_GET['lang']);
if($language) {
    if(!in_array($language, $LangArray)) {
        $_SESSION['NowLang'] = $DefaultLang;
    }else {
        $_SESSION['NowLang'] = $language;
    }
}
$CurentLang = addslashes($_SESSION['NowLang']);
include_once ("lang.".$CurentLang.".php");
if(isset($_GET['lang'])) {
    echo $translate['msgCli'] .' '.  $_SESSION['name'].' ' . $_SESSION['surname'] . $translate['msgCli2'];
}

echo '<br><a href="client.php?lang=ru">Русский</a>';
echo '<br><a href="client.php?lang=en">Англиский</a>';