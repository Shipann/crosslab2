<!DOCTYPE html>
<html>
<body>
    <form action="login.php" method="post">
        Логин
        <input type="text" name="login">
        Пароль
        <input type="password" name="password">
        <button type="submit">Войти</button>
    </form>
</body>
</html>