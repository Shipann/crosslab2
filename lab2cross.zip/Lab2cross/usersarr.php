<?php
$arr = [
    [
        'login' => 'ships',
        'password' => 'artem123',
        'name' => 'Artem',
        'surname' => 'Shybko',
        'role' => 'admin',
    ],
    [
        'login' => 'zohan',
        'password' => '18zozo',
        'name' => 'Zuzu',
        'surname' => 'Bobo',
        'role' => 'manager',
    ],
    [
        'login' => 'machine',
        'password' => 'mordor1sdie',
        'name' => 'Sauron',
        'surname' => 'Sauron',
        'role' => 'client',
    ],


];